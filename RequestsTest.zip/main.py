import requests

URL = 'https://api.pokemonbattle.ru/v2'
TOKEN = '2a88523db1875ac0b0619d9180ade1f6'
HEADER = {'content-type':'application/json' , 'trainer_token': TOKEN}


body_create = {"name": "Python",
    "photo_id": 23
}




response_creation = requests.post(url=f'{URL}/pokemons', headers=HEADER, json=body_create)

print(response_creation.text)

pokemon_id = response_creation.json()['id']

body_change = {
    "pokemon_id" : pokemon_id,
    "name" : "Python2",
    "photo_id" : 23
}

body_catch = {
    "pokemon_id" : pokemon_id
}
response_change = requests.put(url=f'{URL}/pokemons', headers = HEADER, json=body_change)

print(response_change.text)

response_catchinto = requests.post(url=f'{URL}/trainers/add_pokeball', headers=HEADER, json=body_catch)

print(response_catchinto.text)

