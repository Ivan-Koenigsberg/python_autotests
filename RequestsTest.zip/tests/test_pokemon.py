import requests
import pytest

URL = 'https://api.pokemonbattle.ru/v2'
TOKEN = '2a88523db1875ac0b0619d9180ade1f6'
HEADER = {'content-type':'application/json' , 'trainer_token': TOKEN}
TRAINER_ID = '14276'

def test_status_code():
    response = requests.get(url=f'{URL}/trainers')
    assert response.status_code == 200

def test_trainer_name():
    response_list = requests.get(url=f'{URL}/trainers', params={'trainer_id' : TRAINER_ID})
    assert response_list.json()["data"][0]["trainer_name"] == 'FCSM'